---
name: Issue report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

- Describe the bug
- Add a link to a codepen, jsfiddle or other example page which shows the problem
- OS:
- Browser
- Inputmask version
